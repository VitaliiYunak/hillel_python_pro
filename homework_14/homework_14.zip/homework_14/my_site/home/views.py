# from django.http import HttpResponse
from django.shortcuts import render


def home_view(request):
    """
    Головна сторінка сайту
    """
    data = {
        "title": "Головна сторінка",
        "body": "Ласкаво просимо на головну сторінку",
    }
    # return HttpResponse("<h1>Ласкаво просимо на головну сторінку</h1>")
    return render(request, "home/home.html", context=data)


def about_view(request):
    """
    Сторінка про нас
    """
    data = {
        "title": "Сторінка про нас",
        "body": "Сторінка про нас",
    }
    # return HttpResponse("<h1>Сторінка про нас</h1>")
    return render(request, "home/about.html", context=data)


def contact_view(request):
    """
    Сторінка "Контакти"
    """
    data = {
        "title": "Контакти",
        "body": "Зв'яжіться з нами",
    }
    # return HttpResponse("<h1>Зв'яжіться з нами</h1>")
    return render(request, "home/contact.html", context=data)


def post_view(request, post_id):
    """
    Сторінка "Номер посту"
    """
    data = {
        "title": "Пост",
        "post_id": post_id,
    }
    # return HttpResponse(f"<h1>Ви переглядаєте пост з ID: {post_id}</h1>")
    return render(request, "home/post.html", context=data)


def profile_view(request, username):
    """
    Сторінка "Профайл"
    """
    data = {
        "title": "Профайл",
        "username": username,
    }
    # return HttpResponse(f"<h1>Ви переглядаєте профіль користувача: {username}</h1>")
    return render(request, "home/profile.html", context=data)


def event_view(request, year, month, day):
    """
    Сторінка "Дата події"
    """
    data = {
        "title": "Дата події",
        "event_date": f"{day}-{month}-{year}",
    }
    # return HttpResponse(f"<h1>Дата події: {year}-{month}-{day}</h1>")
    return render(request, "home/event.html", context=data)
